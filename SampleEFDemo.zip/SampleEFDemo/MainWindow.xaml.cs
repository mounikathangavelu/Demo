﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SampleEFDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Display_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities contextObj = new SampleEFDemo.Sep19CHNEntities();
            if (txt_empLocation.Text != string.Empty)
            {

                var query = from Employee emp in contextObj.Employees
                            where emp.EmpLocation == txt_empLocation.Text
                            select emp;
                List<Employee> elist = new List<SampleEFDemo.Employee>();
                elist = query.ToList<Employee>();
                if (elist.Count <= 0) { MessageBox.Show("No records Found"); }
                else
                {
                    dg_Emp.ItemsSource = elist;
                }
            }
            else MessageBox.Show("Please enter Location");
        }

        private void btn_deleteEmp(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities contextObj = new SampleEFDemo.Sep19CHNEntities();
                Employee empToBeDeleted;//
                int empId = Convert.ToInt32(txt_empId.Text);
                empToBeDeleted = contextObj.Employees.FirstOrDefault(emp => emp.EmpId == empId);
                if (empToBeDeleted != null)
                {
                    contextObj.Employees.Remove(empToBeDeleted);//delete operation
                    contextObj.SaveChanges();//save changes back to the DB
                    MessageBox.Show("Employee Details deleted");

                }
                else throw new Exception("Delete could not be found");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
