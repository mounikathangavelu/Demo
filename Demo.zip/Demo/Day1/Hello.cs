public class Demo
{
	public static void Main()
	{
		System.Console.WriteLine("Hello .NET Batch");
	}
}