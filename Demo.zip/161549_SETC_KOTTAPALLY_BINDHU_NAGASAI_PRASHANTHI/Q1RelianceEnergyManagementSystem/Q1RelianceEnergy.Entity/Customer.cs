﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1RelianceEnergy.Entity
{
    /// <summary>
    /// Customer Bill No : Customer's payment bill number
    /// Customer Id : Customer's Id number
    /// Description : This is an Entity Class for Customer
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    public class Customer
    {
        //Get or Set Bill No
        public int BillNo { get; set; }

        //Get or Set Customer ID
        public int CustomerID { get; set; }

        //Get or Set CustomerName
        public string CustomerName { get; set; }

        //Get or Set Phone Number
        public string Phone { get; set; }

        //Get or Set Customer Address
        public string CustomerAddress { get; set; }

        //Get or set Customer Email ID
        public string Email { get; set; }

        //Get or set Units Consumed
        public double UnitsConsumed { get; set; }

        //Get or Set Rate
        public double Rate { get; set; }

        //Get or Set Amount
        public double Amount { get; set; }

        //Get or Set Surcharge
        public double Surcharge { get; set; }

        //Get or Set Gross Amount
        public double GrossAmount { get; set; }
        
    }
}
