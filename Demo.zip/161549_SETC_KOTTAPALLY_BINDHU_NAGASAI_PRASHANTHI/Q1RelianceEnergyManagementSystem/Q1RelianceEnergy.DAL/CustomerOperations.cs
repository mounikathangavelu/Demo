﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Q1RelianceEnergy.Entity;
using RelianceEnergy.Exception;

namespace Q1RelianceEnergy.DAL
{
    /// <summary>
    /// Customer Bill No : Customer's payment bill number
    /// Customer Id : Customer's Id number
    /// Description : This class will contain the operations for Customer
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    public class CustomerOperations
    {
        static List<Customer> cstList = new List<Customer>();

        //Method to add new customer
        public static bool AddCustomer(Customer cst)
        {
            bool isAdded = false;

            try
            {
                //Adding customer in the list
                cstList.Add(cst);
                isAdded = true;
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isAdded;
        }

        //Method to search customer information
        public static Customer SearchCustomer(int cstID)
        {
            Customer cst = null;

            try
            {
                //Searching customer
                cst = cstList.Find(e => e.CustomerID == cstID);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cst;
        }
       
        //Method to display all customers
        public static List<Customer> DisplayCustomers()
        {
            return cstList;
        }

    }
}
