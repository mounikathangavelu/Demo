﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Q1RelianceEnergy.Entity;
using RelianceEnergy.Exception;
using Q1RelianceEnergy.BL;

namespace Q1RelianceEnergyPresentationLayer
{
    class Program
    {
        //Method to add new employee
        public static void AddCustomer()
        {
            try
            {
                Customer cst = new Customer();

                Console.Write("Enter Customer Bill No : ");
                cst.BillNo = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Customer ID : ");
                cst.CustomerID = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Customer Name : ");
                cst.CustomerName = Console.ReadLine();

                Console.Write("Enter Customer Phone No : ");
                cst.Phone = Console.ReadLine();

                Console.Write("Enter Customer Address : ");
                cst.CustomerAddress = Console.ReadLine();

                Console.Write("Enter Customer Email Address : ");
                cst.Email = Console.ReadLine();

                Console.Write("Enter total units consumed: ");
                cst.UnitsConsumed = Convert.ToDouble(Console.ReadLine());

                Console.Write("Enter the rate of interest : ");
                cst.Rate = Convert.ToDouble(Console.ReadLine());

                cst.Amount = (cst.UnitsConsumed * cst.Rate);

                cst.Surcharge = (0.05 * cst.Amount);

                cst.GrossAmount = (cst.Amount + cst.Surcharge);


                bool isAdded = CustomerValidations.AddCustomer(cst);

                if (isAdded)
                {
                    Console.WriteLine("Customer details added successfully");
                }
                else
                    throw new CustomerException("Customer details not added");
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Method to add search customer
        public static void SearchCustomer()
        {
            try
            {
                int cstID;

                Console.Write("Enter Customer ID for Search : ");
                cstID = Convert.ToInt32(Console.ReadLine());

                Customer cst = CustomerValidations.SearchCustomer(cstID);

                if (cst != null)
                {
                    Console.WriteLine("Customer ID : " + cst.CustomerID);
                    Console.WriteLine("Customer Name : " + cst.CustomerName);
                    Console.WriteLine("Customer Address : " + cst.CustomerAddress);
                    Console.WriteLine("Customer Phone : " + cst.Phone);
                    Console.WriteLine("Customer Email : " + cst.Email);
                    Console.WriteLine("Gross Amount : " + cst.GrossAmount);
                }
                else
                    throw new CustomerException("Customer " + cstID + " not found");
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //method to display all customers
        public static void DisplayCustomers()
        {
            try
            {
                List<Customer> cstList = CustomerValidations.DisplayCustomers();

                if (cstList != null || cstList.Count > 0)
                {
                    Console.WriteLine("***********************************************************************************************************************");
                    Console.WriteLine("Customer BillNo     Customer ID       Customer Name    Customer Phone    Customer Address    Customer Email      Customer Units Consumed     Customer Rate   Customer Amount     Customer Surcharge  Customer Gross Amount");
                    Console.WriteLine("***********************************************************************************************************************");
                    foreach (Customer cst in cstList)
                    {
                        Console.WriteLine(cst.BillNo + "\t" + cst.CustomerID + "\t" + cst.CustomerName + "\t" + cst.Phone + "\t" + cst.CustomerAddress + "\t" + cst.Email + "\t" + cst.UnitsConsumed + "\t" + cst.Rate + "\t" + cst.Amount + "\t" + cst.Surcharge + "\t" + cst.GrossAmount);
                    }
                    Console.WriteLine("***********************************************************************************************************************");
                }
                else
                    throw new CustomerException("Customer Details not available");
            }
            catch (CustomerException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("----------------------------");
            Console.WriteLine("1. Add Customer");
            Console.WriteLine("2. Search Customer");
            Console.WriteLine("3.Display Customers");
            Console.WriteLine("4.. Exit");
            Console.WriteLine("----------------------------");
        }

        static void Main(string[] args)
        {

            try
            {
                int choice;

                do
                {
                    PrintMenu();
                    Console.Write("Enter your choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            AddCustomer();
                            break;
                        case 2:
                            SearchCustomer();
                            break;
                        case 3:
                            DisplayCustomers();
                            break;
                        case 4:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.Write("Invalid Choice");
                            break;
                    }
                } while (choice != 4);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
