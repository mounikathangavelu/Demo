﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RelianceEnergy.Exception
{
    /// <summary>
    /// Customer Bill No : Customer's payment bill number
    /// Customer Id : Customer's Id number
    /// Description : This is an Exception Class for Customer
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    public class CustomerException : ApplicationException
    {
        //Default Constructor
        public CustomerException()
            : base()
        { }

        //Parameterized constructor with message parameter
        public CustomerException(string message)
            : base(message)
        { }
    }
}
