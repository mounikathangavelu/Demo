﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Q1RelianceEnergy.Entity;
using RelianceEnergy.Exception;
using Q1RelianceEnergy.DAL;

namespace Q1RelianceEnergy.BL
{
    /// <summary>
    /// Customer Bill No : Customer's payment bill number
    /// Customer Id : Customer's Id number
    /// Description : This class will have the business logic for Customer
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    public class CustomerValidations
    {
        //Method to validate customer details
        public static bool ValidateCustomer(Customer cst)
        {
            bool isValidated = true;

            StringBuilder message = new StringBuilder();

            try
            {
                //Checking employee id that it should not be empty
                if (cst.CustomerID == 0)
                {
                    message.Append("Customer ID cannot be empty\n");
                    isValidated = false;
                }

                //Checking employee bill number that it should not be empty
                if (cst.BillNo == 0)
                {
                    message.Append("Customer Bill No cannot be empty\n");
                    isValidated = false;
                }

                //Checking customer name
                if (cst.CustomerName == string.Empty)
                {
                    message.Append("Customer Name should be provided\n");
                    isValidated = false;
                }
                else if (!Regex.IsMatch(cst.CustomerName, "[A-Z][a-z]{2,}"))
                {
                    message.Append("Customer Name should start with Capital Alphabet, it should have minimum 3 characters and only alphabets\n");
                    isValidated = false;
                }

                //Checking Phone Number
                if (!Regex.IsMatch(cst.Phone, "[0-9]{10}"))
                {
                    message.Append("Phone number should  have exactly 10 digits\n");
                    isValidated = false;
                }

                //Checking Amount
                if(cst.Amount != (cst.UnitsConsumed*cst.Rate))
                {
                    message.Append("Amount has to be units consumed * Rate");
                    isValidated = false;
                }

                //Checking Surcharge
                if (cst.Surcharge != (0.05*cst.Amount))
                {
                    message.Append("Surcharge has to be 5% of Amount");
                    isValidated = false;
                }

                //Checking Gross Amount
                if (cst.GrossAmount != (cst.Amount+cst.Surcharge))
                {
                    message.Append("Gross Amount has to be sum of Amount and Surcharge");
                    isValidated = false;
                }

                if (isValidated == false)
                    throw new CustomerException(message.ToString());
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isValidated;
        }

        //Method to add new employee
        public static bool AddCustomer(Customer cst)
        {
            bool isAdded = false;

            try
            {
                //Validating customer details
                if (ValidateCustomer(cst))
                {
                    //Adding the employee by calling DAL Add method
                    isAdded = CustomerOperations.AddCustomer(cst);
                }
                else
                    throw new CustomerException("Please provide valid employee details");
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isAdded;
        }

        //Method to search employee
        public static Customer SearchCustomer(int cstID)
        {
            Customer cst = null;

            try
            {
                //Searching Customer by calling DAL search method
                cst = CustomerOperations.SearchCustomer(cstID);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cst;
        }

        //Method to display all customers
        public static List<Customer> DisplayCustomers()
        {
            List<Customer> cstList = null;

            try
            {
                //displaying Customer by calling DAL display method
                cstList = CustomerOperations.DisplayCustomers();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cstList;
        }



    }
}
