﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    public delegate Double MyDelegate(double val1, double val2);

    class Program
    {
        public static double BalanceDue(double amtcollected, double amtdue)
        {
            return amtcollected - amtdue;
        }


        static void Main(string[] args)
        {

            //calling method using delegate
            MyDelegate del1 = new MyDelegate(BalanceDue);
            double res1 = del1(10000, 5000);
            Console.WriteLine("Balance due by calling method using delegate is:" + res1);

            //calling using anonymous method
            MyDelegate del2 = delegate (double amtcollected, double amtdue)
            { return amtcollected - amtdue; };
            double res2 = del2(10000, 5000);
            Console.WriteLine("Balance due by using anonymous method is:" + res2);

            //calling using lambda expression
            MyDelegate del3 = (amtcollected, amtdue) => { return amtcollected - amtdue; };
            double res3 = del3(10000, 5000);
            Console.WriteLine("Balance due by using lambda expression is:" + res3);
      
            Console.ReadKey();
        }
    }
}
