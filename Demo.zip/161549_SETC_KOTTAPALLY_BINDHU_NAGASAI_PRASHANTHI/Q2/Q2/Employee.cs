﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Employee
    {
        int empid;
        //properties
        public int EmpID   
        {
            set { empid = value; }
            get { return empid; }
        }

        string empname;
        public string EmpName
        {
            set { empname = value; }
            get { return empname; }
        }

        char empgender;
        public char EmpGender
        {
            set { empgender = value; }
            get { return empgender; }
        }

        string dob;
        public string EmpDOB
        {
            set { dob = value; }
            get { return dob; }
        }

        //default constructor
        public Employee()
        {
            EmpID = 0;
            EmpName = "";
            EmpGender = ' ';
            EmpDOB = "";
        }

        //parameterized constructor
        public Employee(int empid, string empname, char empgender, string dob)
        {
            this.EmpID = empid;
            this.EmpName = empname;
            this.EmpGender = empgender;
            this.EmpDOB = dob;
        }

        //method
        public void DisplayDetails()
        {
            Console.WriteLine("Employee ID : " + EmpID);
            Console.WriteLine("Employee Name : " + EmpName);
            Console.WriteLine("Employee Gender : " + EmpGender);
            Console.WriteLine("Employee Date of Birth : " + EmpDOB);
        }



    }
}
