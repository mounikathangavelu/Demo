﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee(101, "Bindhu", 'F', "11/09/1997");
            //invoking method
            emp.DisplayDetails();

            Console.ReadKey();
        }
    }
}
